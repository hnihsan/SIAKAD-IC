<!--Ini File Head-->
<html>
<head>
	<title>Islamic Center Student's</title>
	<!-- <link rel='stylesheet' href='style.css'/> -->
</head>
<body>
	<div id='container'>
		<div id='header'>
			<h1>Islamic Center</h1>
			<h3>Informasi Akademik Peserta Didik</h3>
		</div>
		<div id="navbar">
			Selamat datang, User.
		</div>
		<div id='sidebar'>
			<ul>
				<li><a href="index.php?hal=home">Beranda</a></li>
                <li><a href="index.php?hal=absensi">Absensi</a></li>
                <li><a href="index.php?hal=nilai">Nilai</a></li>
                <li><a href="index.php?hal=matpel">Mata Pelajaran</a></li>	
			</ul>
		</div>
		

