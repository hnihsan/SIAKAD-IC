<h2 class='judul'>Data Mata Pelajaran Islamic Center</h2>
<p>
		<table>
			<tr>
				<th>No.</th>
				<th>Kode</th>
				<th>Nama Pelajaran</th>								

			</tr>
			<tr>
				<td>1</td>
				<td>0001</a></td>
				<td><a href="index.php?hal=dtlmatpel&q=#">Pelajaran 1</a></td>
			</tr>
			<tr>
				<td>+</td>
				<td><a href="index.php?hal=tmmatpel">Tambah Mata Pelajaran..</a></td>
			</tr>			
		</table>
					
</p>