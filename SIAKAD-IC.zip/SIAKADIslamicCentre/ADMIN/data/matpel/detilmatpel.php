<h2 class="judul">Data Mata Pelajaran</h2>
<p>
	<table>		
		<tr>
			<th>Kode :</th>
			<td>0001</td>
		</tr>	
		<tr>	
			<th>Nama Pelajaran:</th>
			<td>Pelajaran 1</td>
		</tr>
		
		<tr>	
			<th>Jadwal :</th>
			<td>
				<table border="1">
					<tr>
						<th>No.</th>
						<th>Kode</th>
						<th>Kelas</th>
						<th>Guru</th>
						<th>Sesi</th>
					</tr>
					<tr>
						<td>1</td>
						<td>J01</td>
						<td>X3</td>
						<td>Guru 1</td>
						<td>Senin, 08.00-09.00</td>
					</tr>
				</table>
			</td>
		</tr>	
		
	</table>
	<a href="index.php?hal=dbmatpel">Kembali</a>
</p>