<h2 class="judul">Data Siswa</h2>
<p>
	<table>		
		<tr>
			<th>NIS :</th>
			<td>0001</td>
		</tr>	
		<tr>	
			<th>Nama :</th>
			<td>Siswa 1</td>
		</tr>
		<tr>	
			<th>Alamat :</th>
			<td>Jalan2</td>
		</tr>
		<tr>	
			<th>tempat Lahir :</th>
			<td>Jakarta</td>
		</tr>
		<tr>	
			<th>Tanggal Lahir :</th>
			<td>01-01-1990</td>
		</tr>
		<tr>
			<th>Kelas :</th>
			<td>X1</td>
		</tr>
			
		
	</table>
	<a href="index.php?hal=dbsiswa">Kembali</a>
</p>