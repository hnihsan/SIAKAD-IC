<h2 class='judul'>Data Guru Islamic Center</h2>
<p>
		<table>
			<tr>
				<th>No.</th>
				<th>NIP</th>
				<th>Nama</th>				
				<th>Wali Kelas</th>

			</tr>
			<tr>
				<td>1</td>
				<td>0001</a></td>
				<td><a href="index.php?hal=dtlguru&q=#">Guru 1</a></td>
				<td>X3</td>
			</tr>
			<tr>
				<td>+</td>
				<td><a href="index.php?hal=tmguru">Tambah data..</a></td>
			</tr>			
		</table>
					
</p>