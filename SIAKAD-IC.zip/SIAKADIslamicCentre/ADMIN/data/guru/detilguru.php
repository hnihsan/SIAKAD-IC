<h2 class="judul">Data Guru</h2>
<p>
	<table>		
		<tr>
			<th>NIP :</th>
			<td>0001</td>
		</tr>	
		<tr>	
			<th>Nama :</th>
			<td>Guru 1</td>
		</tr>
		<tr>	
			<th>Alamat :</th>
			<td>Jalan2</td>
		</tr>
		<tr>	
			<th>tempat Lahir :</th>
			<td>Jakarta</td>
		</tr>
		<tr>	
			<th>Tanggal Lahir :</th>
			<td>01-01-1990</td>
		</tr>
		<tr>
			<th>Wali Kelas :</th>
			<td>X1</td>
		</tr>
		<tr>	
			<th>Mata Pelajaran :</th>
			<td>Pelajaran 1</td>
		</tr>
		<tr>	
			<th>Jadwal Pengajaran :</th>
			<td>
				<table border="2">
					<tr>
						<th>No.</th>
						<th>Kode</th>
						<th>Pelajaran</th>
						<th>Kelas</th>
						<th>Sesi</th>
					</tr>
					<tr>
						<td>1</td>
						<td>J01</td>
						<td>Pelajaran 1</td>
						<td>X3</td>
						<td>Senin, 08.00-09.00</td>
					</tr>
				</table>
			</td>
		</tr>	
		
	</table>
	<a href="index.php?hal=dbguru">Kembali</a>
</p>