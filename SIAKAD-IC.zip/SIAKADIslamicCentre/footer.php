<!--ini file footer-->
<div id='footer'>
			<p>&copy;2016</p>
		</div>
	</div>
</body>
</html>
