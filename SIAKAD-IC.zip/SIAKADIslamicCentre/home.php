<h2 class='judul'>Selamat datang di Sistem Informasi Peserta Didik Islamic Center .</h2>
			<p> Di sini tersedia informasi mulai dari absensi, hingga rekapitulasi hasil belajar peserta didik selama menjadi murid di Islamic Center.
			</p>

		
