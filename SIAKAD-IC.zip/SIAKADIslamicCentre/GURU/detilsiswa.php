<h2 class="judul">Nama Siswa</h2>
<p>
	<table>
		<tr>
			<th>No.</th>
			<th>Kode</th>
			<th>Mata Pelajaran</th>
			<th>Absen</th>
			<th>Tugas</th>
			<th>UH</th>
			<th>UTS</th>
			<th>UAS</th>
		</tr>
	</table>
	<a href="index.php?hal=walikls">Kembali</a>
</p>