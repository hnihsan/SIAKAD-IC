<h3>ubah</h3>
<form>
	<p>ID : <input type=text name='idmember' required maxlength='10'></p>
	<p>Nama : <input type=text name='nmmember' required maxlength='10'></p>	
	<input type=submit name='ubah' value='ubah'>
	<a href='index.php?hal=profil'>Kembali</a>
</form>