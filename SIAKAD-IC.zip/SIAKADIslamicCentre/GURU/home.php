<h2 class='judul'>Agenda mengajar hari ini :</h2>
<p>
		<table>
			<tr>
				<th>No.</th>
				<th>Mata Pelajaran</th>
				<th>Kelas</th>				
				<th>Sesi</th>
			</tr>
			<tr>
				<td>1</td>
				<td><a href="index.php?hal=detilkls">Matematika</a></td>
				<td>X3</td>
				<td>19.30 s/d 21.00</td>
			</tr>			
		</table>			
</p>