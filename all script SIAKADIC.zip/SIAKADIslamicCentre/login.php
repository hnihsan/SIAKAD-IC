<h2 class='judul'>Login</h2>
	<form method="post" action="USER/index.php">
		<p><input type=text name='usr' placeholder='Username'/></p>
		<p><input type=password name='pass' placeholder='Password'/></p>
		<p><input type=submit name='login' value='Login' /></p>
	</form>
	