<!--Ini File Head-->
<html>
<head>
	<title>Islamic Center | Administrator</title>
	<!-- <link rel='stylesheet' href='style.css'/> -->
</head>
<body>
	<div id='container'>
		<div id='header'>
			<h1>Administrator</h1>
		</div>
		<div id='navbar'>
			<ul>
                <li><a href="index.php?hal=dbguru">Data Guru</a></li>
				<li><a href="index.php?hal=dbsiswa">Data Siswa</a></li>
				<li><a href="index.php?hal=dbkelas">Data Kelas</a></li>
				<li><a href="index.php?hal=dbmatpel">Mata Pelajaran</a></li>
				<li><a href="index.php?hal=dbjadwal">Jadwal Pengajaran</a></li>
			</ul>
		</div>
		

