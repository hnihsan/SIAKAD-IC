<h2 class='judul'>Data Peserta Didik Islamic Center</h2>
<p>
		<table>
			<tr>
				<th>No.</th>
				<th>NIS</th>
				<th>Nama</th>				
				<th>Kelas</th>

			</tr>
			<tr>
				<td>1</td>
				<td>0001</a></td>
				<td><a href="index.php?hal=dtlsiswa&q=#">Siswa 1</a></td>
				<td>X3</td>
			</tr>
			<tr>
				<td>+</td>
				<td><a href="index.php?hal=tmsiswa">Tambah data..</a></td>
			</tr>			
		</table>
					
</p>