<h2 class='judul'>Data Jadwal Belajar Mengajar</h2>
<p>
		<table>
			<tr>
				<th>No.</th>
				<th>Kode</th>
				<th>Pelajaran</th>				
				<th>Kelas</th>
				<th>Guru</th>
				<th>Sesi</th>

			</tr>
			<tr>
				<td>1</td>
				<td>J01</a></td>
				<td><a href="index.php?hal=dtlmatpel&q=#">Pelajaran 1</a></td>
				<td><a href="index.php?hal=dtlkelas&q=#">X3</a></td>
				<td><a href="index.php?hal=dtlguru&q=#">Guru 1</a></td>
				<td>08.00-09.00</td>
				
			</tr>
			<tr>
				<td>+</td>
				<td><a href="index.php?hal=tmjadwal">Tambah Jadwal..</a></td>
			</tr>			
		</table>
					
</p>