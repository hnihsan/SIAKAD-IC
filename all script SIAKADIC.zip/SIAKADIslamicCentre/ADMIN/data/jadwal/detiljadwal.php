<h2 class="judul">Data Jadwal</h2>
<p>
	<table>		
		<tr>
			<th>Kode :</th>
			<td>0001</td>
		</tr>	
		<tr>	
			<th>Pelajaran:</th>
			<td>Pelajaran 1</td>
		</tr>
		<tr>	
			<th>Kelas:</th>
			<td>Kelas 1</td>
		</tr>
		<tr>	
			<th>Guru:</th>
			<td>Guru 1</td>
		</tr>
		<tr>	
			<th>Sesi:</th>
			<td>Rabu, 08.00-09.00</td>
		</tr>	
		
	</table>
	<a href="index.php?hal=dbjadwal">Kembali</a>
</p>