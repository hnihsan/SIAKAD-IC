<h2 class='judul'>Data Kelas Islamic Center</h2>
<p>
		<table>
			<tr>
				<th>No.</th>
				<th>Kode</th>
				<th>Nama Kelas</th>				
				<th>Wali Kelas</th>

			</tr>
			<tr>
				<td>1</td>
				<td>k01</a></td>
				<td><a href="index.php?hal=dtlkelas&q=#">X1</a></td>
				<td>Guru 1</td>
			</tr>
			<tr>
				<td>+</td>
				<td><a href="index.php?hal=tmkelas">Tambah data..</a></td>
			</tr>			
		</table>
					
</p>