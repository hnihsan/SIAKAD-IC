<h2 class="judul">Data Kelas</h2>
<p>
	<table border="2">		
		<tr>
			<th>Kode</th>
		</tr>	
		<tr>	
			<th>Nama Kelas</th>
		</tr>
		<tr>
			<th>Wali Kelas</th>
		</tr>
		<tr>
			<th>Siswa :</th>
			<td>
				<table border="1">
					<tr>
						<th>No.</th>
						<th>NIS</th>
						<th>Nama</th>
					</tr>
					<tr>
						<td>1</td>
						<td>0001</td>
						<td>Siswa 1</td>
					</tr>
					<tr>
						<td>+</td>
						<td>Tambah siswa</td>
						<td></td>
					</tr>
				</table>
			</td>
		</tr>
		<tr>
			<th>Jadwal Pengajaran :</th>
			<td>
				<table border="1">
					<tr>
						<th>No.</th>
						<th>Kode</th>
						<th>Nama Pelajaran</th>
						<th>Guru</th>
						<th>Sesi</th>
					</tr>
					<tr>
						<td>1</td>
						<td>P001</td>
						<td>Pelajaran 1</td>
						<td>Guru 1</td>
						<td>Senin, 08.00-09.30</td>
					</tr>
				</table>
			</td>
		</tr>
		
	</table>
	<a href="index.php?hal=dbkelas">Kembali</a>
</p>