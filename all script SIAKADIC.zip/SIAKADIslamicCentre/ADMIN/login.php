<html>
	<head>
		<title>Login | Admin</title>
	</head>
	<body>
	<form>
		<p><input type=text name='usr' placeholder='Username'/></p>
		<p><input type=password name='pass' placeholder='Password'/></p>
		<p><input type=submit name='login' value='Login' /></p>
	</form>
	</body>
</html>