<h2 id="judul">Penilaian</h2>
<p>
	<select name="pertemuan">
		<option>--Pilih Pertemuan--</option>
	</select>
	<table>
		<tr>
			<th>No.</th>
			<th>NIS</th>
			<th>Nama</th>
			<th>Tugas</th>
			<th>UH</th>
			<th>UTS</th>
			<th>UAS</th>
		</tr>
	</table>
</p>