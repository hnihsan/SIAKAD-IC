<h2 class="judul">Pertemuan</h2>
<p>
	<table>
		<tr>
			<th>Pertemuan</th>
			<th>Hari/Tanggal</th>
			<th>Sesi</th>
			<th>Keterangan</th>
		</tr>
	</table>
</p>