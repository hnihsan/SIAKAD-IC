<h2 id="judul">Absensi</h2>
<p>
	<select name="pertemuan">
		<option>--Pilih Pertemuan--</option>
	</select>
	<table>
		<tr>
			<th>No.</th>
			<th>NIS</th>
			<th>Nama</th>
			<th>Keterangan</th>
		</tr>
	</table>
</p>