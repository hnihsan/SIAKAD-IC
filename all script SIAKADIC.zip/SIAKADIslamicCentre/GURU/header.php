<!--Ini File Head-->
<html>
<head>
	<title>Islamic Center Teacher's</title>
	<!-- <link rel='stylesheet' href='style.css'/> -->
</head>
<body>
	<div id='container'>
		<div id='header'>
			<h1>Islamic Center</h1>
			<h3>Pengajar & Wali Kelas</h3>
		</div>
		<div id="navbar">
			Selamat datang, User.
		</div>
		<div id='sidebar'>
			<ul>
				<li><a href="index.php?hal=home">Beranda</a></li>
                <li><a href="index.php?hal=semuakls">Semua Kelas</a></li>
                <li><a href="index.php?hal=walikls">Wali Kelas</a></li>	
            </ul>
		</div>
		

