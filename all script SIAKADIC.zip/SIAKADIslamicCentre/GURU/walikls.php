<h2 id="judul">Wali Kelas *Nama kelas*</h2>
<p>
	<table>
		<tr>
			<th>No.</th>
			<th>NIS</th>
			<th>Nama</th>			
		</tr>
		<tr>
			<td>1</td>
			<td><a href="detilsiswa.php?q=#">00001</a></td>
			<td><a href="detilsiswa.php?q=#">Contoh Siswa</a></td>
		</tr>
	</table>
</p>