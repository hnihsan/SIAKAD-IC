<?php
//ambil judul dan data member dari database
?>
<h2 class='judul'>Profil</h2>
	<p>
		<table>			
			<tr>
				<th>ID :</th>
				<th></th>				
			</tr>
			<tr>
				<th>Nama :</th>
				<th></th>				
			</tr>
			<tr>
				<th>Alamat :</th>
				<th></th>				
			</tr>			
		</table>
		<p><button>Ubah</button><a href="index.php?hal=home">Kembali</a></p>